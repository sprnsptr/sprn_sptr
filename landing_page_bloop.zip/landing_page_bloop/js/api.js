76// API Service untuk Social Media App
class ApiService {
    constructor() {
        // Gunakan konfigurasi dari config.js jika tersedia
        this.baseURL = window.getApiUrl ? window.getApiUrl() : 'http:// 10.46.1.136:8000/api';
        this.token = localStorage.getItem('auth_token');
        this.config = window.getConfig ? window.getConfig() : {
            API_TIMEOUT: 10000,
            MAX_RETRY_ATTEMPTS: 3,
            RETRY_DELAY: 1000
        };
    }

    // Helper method untuk request API dengan retry logic
    async makeRequest(endpoint, options = {}, retryCount = 0) {
        const url = `${this.baseURL}${endpoint}`;
        
        const defaultOptions = {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
            }
        };

        // Tambahkan token jika ada
        if (this.token) {
            defaultOptions.headers['Authorization'] = `Bearer ${this.token}`;
        }

        const config = {
            ...defaultOptions,
            ...options,
            headers: {
                ...defaultOptions.headers,
                ...options.headers
            }
        };

        try {
            // Tambahkan timeout
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), this.config.API_TIMEOUT);
            
            const response = await fetch(url, {
                ...config,
                signal: controller.signal
            });
            
            clearTimeout(timeoutId);
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            
            // Retry logic untuk error network
            if (retryCount < this.config.MAX_RETRY_ATTEMPTS && 
                (error.name === 'AbortError' || error.message.includes('Failed to fetch'))) {
                
                console.log(`Retrying request (${retryCount + 1}/${this.config.MAX_RETRY_ATTEMPTS})...`);
                
                await new Promise(resolve => setTimeout(resolve, this.config.RETRY_DELAY));
                return this.makeRequest(endpoint, options, retryCount + 1);
            }
            
            throw error;
        }
    }

    // Post endpoints
    async getAllPosts() {
        return this.makeRequest('/posts');
    }

    // Story endpoints
    async getAllStories() {
        return this.makeRequest('/stories');
    }

    // Feedback endpoints
    /**
     * Kirim feedback hanya dengan subject dan message (tanpa name/email)
     * @param {{subject: string, message: string}} feedbackData
     */
    async submitFeedback(feedbackData) {
        // Hanya kirim subject dan message ke backend
        return this.makeRequest('/feedback', {
            method: 'POST',
            body: JSON.stringify({
                subject: feedbackData.subject,
                message: feedbackData.message
            })
        });
    }

    async getFeedback() {
        return this.makeRequest('/feedback');
    }
}

// Inisialisasi API service
const api = new ApiService();

// Export untuk penggunaan global
window.api = api;
