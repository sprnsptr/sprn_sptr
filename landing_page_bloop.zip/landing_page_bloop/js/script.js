// Efek scroll pada header: menambah/menghapus class 'scrolled' saat discroll
window.addEventListener('scroll', function() {
    const header = document.querySelector('header');
    if (window.scrollY > 100) {
        header.classList.add('scrolled');
    } else {
        header.classList.remove('scrolled');
    }
});

// Smooth scroll untuk navigasi anchor
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Animasi muncul saat elemen masuk viewport
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};
const observer = new IntersectionObserver(function(entries) {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);
document.querySelectorAll('.service-item, .card, .feature-item').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(30px)';
    el.style.transition = 'all 0.6s ease';
    observer.observe(el);
});

// Efek parallax pada home section
window.addEventListener('scroll', function() {
    const scrolled = window.pageYOffset;
    const homeSection = document.querySelector('.home-section');
    if (homeSection) {
        homeSection.style.transform = `translateY(${scrolled * 0.5}px)`;
    }
});

// Fade-in body saat halaman selesai dimuat
window.addEventListener('load', function() {
    document.body.style.opacity = '0';
    document.body.style.transition = 'opacity 0.5s ease';
    setTimeout(() => {
        document.body.style.opacity = '1';
    }, 100);
});

// Fungsi animasi counter angka (misal pada pricing)
function animateCounter(element, target, duration = 2000) {
    let start = 0;
    const increment = target / (duration / 16);
    function updateCounter() {
        start += increment;
        if (start < target) {
            element.textContent = Math.floor(start);
            requestAnimationFrame(updateCounter);
        } else {
            element.textContent = target;
        }
    }
    updateCounter();
}

// Trigger animasi counter saat pricing section terlihat
const pricingObserver = new IntersectionObserver(function(entries) {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            const priceElements = entry.target.querySelectorAll('.price h1');
            priceElements.forEach(el => {
                const price = parseInt(el.textContent.replace('$', ''));
                animateCounter(el, price);
            });
            pricingObserver.unobserve(entry.target);
        }
    });
}, { threshold: 0.5 });
const pricingSection = document.querySelector('.pricing-section');
if (pricingSection) {
    pricingObserver.observe(pricingSection);
}

// Efek hover pada gambar (membesar saat mouse di atasnya)
document.querySelectorAll('img').forEach(img => {
    img.addEventListener('mouseenter', function() {
        this.style.transform = 'scale(1.05)';
        this.style.transition = 'transform 0.3s ease';
    });
    img.addEventListener('mouseleave', function() {
        this.style.transform = 'scale(1)';
    });
});

// Menu mobile: toggle show/hide dan auto-close saat link diklik
const navbarToggler = document.querySelector('.navbar-toggler');
const navbarCollapse = document.querySelector('.navbar-collapse');
if (navbarToggler && navbarCollapse) {
    navbarToggler.addEventListener('click', function() {
        navbarCollapse.classList.toggle('show');
    });
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', function() {
            navbarCollapse.classList.remove('show');
        });
    });
}

// Efek mengetik pada judul utama home section
function typeWriter(element, text, speed = 100) {
    let i = 0;
    element.innerHTML = '';
    function type() {
        if (i < text.length) {
            element.innerHTML += text.charAt(i);
            i++;
            setTimeout(type, speed);
        }
    }
    type();
}
window.addEventListener('load', function() {
    const mainHeading = document.querySelector('.home-text h1');
    if (mainHeading) {
        const originalText = mainHeading.textContent;
        setTimeout(() => {
            typeWriter(mainHeading, originalText, 50);
        }, 1000);
    }
});

// Animasi muncul pada langkah tutorial
tutorialObserver = new IntersectionObserver(function(entries) {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, { threshold: 0.1 });
document.querySelectorAll('.tutorial-step').forEach(step => {
    step.style.opacity = '0';
    step.style.transform = 'translateY(30px)';
    step.style.transition = 'all 0.6s ease';
    tutorialObserver.observe(step);
});

// Kelas untuk mengelola post (ambil, render, like, comment, share, refresh, pagination)
class PostsManager {
    constructor() {
        console.log('PostsManager constructor called');
        this.posts = [];
        this.currentPage = 1;
        this.loading = false;
        this.hasMore = true;
        this.postsContainer = document.getElementById('postsRow');
        this.loadMoreBtn = document.getElementById('loadMorePosts');
        this.refreshBtn = document.getElementById('refreshPosts');
        console.log('Posts container found:', !!this.postsContainer);
        console.log('Load more button found:', !!this.loadMoreBtn);
        console.log('Refresh button found:', !!this.refreshBtn);
        this.init();
    }
    async init() {
        this.bindEvents();
        await this.loadPosts();
    }
    bindEvents() {
        if (this.loadMoreBtn) {
            this.loadMoreBtn.addEventListener('click', () => this.loadMorePosts());
        }
        if (this.refreshBtn) {
            this.refreshBtn.addEventListener('click', () => this.refreshPosts());
        }
    }
    async loadPosts() {
        if (this.loading) return;
        this.loading = true;
        this.showLoading();
        try {
            const response = await api.getAllPosts();
            console.log('API Response:', response);
            let postsData = [];
            if (response && Array.isArray(response)) {
                postsData = response;
            } else if (response && response.data && Array.isArray(response.data)) {
                postsData = response.data;
            } else if (response && response.data && Array.isArray(response.data.data)) {
                postsData = response.data.data;
            }
            console.log('Posts data:', postsData);
            if (postsData.length > 0) {
                this.posts = postsData;
                this.renderPosts();
            } else {
                this.showNoPosts();
            }
        } catch (error) {
            console.error('Error loading posts:', error);
            this.showError('Gagal memuat post dari server. Silakan coba lagi.');
        } finally {
            this.loading = false;
            this.hideLoading();
        }
    }
    async loadMorePosts() {
        if (this.loading || !this.hasMore) return;
        this.currentPage++;
        this.loading = true;
        try {
            const response = await api.getAllPosts();
            if (response && response.data && response.data.length > 0) {
                this.posts = [...this.posts, ...response.data];
                this.renderPosts();
            } else {
                this.hasMore = false;
                this.loadMoreBtn.style.display = 'none';
            }
        } catch (error) {
            console.error('Error loading more posts:', error);
            this.currentPage--;
        } finally {
            this.loading = false;
        }
    }
    async refreshPosts() {
        this.currentPage = 1;
        this.hasMore = true;
        this.loadMoreBtn.style.display = 'block';
        await this.loadPosts();
    }
    renderPosts() {
        if (!this.postsContainer) return;
        if (this.posts.length === 0) {
            this.showNoPosts();
            return;
        }
        // Batasi jumlah story yang ditampilkan, misal 10
        const limit = 20;
        const limitedPosts = this.posts.slice(0, limit);
        const postsHTML = limitedPosts.map(posts => this.createPostHTML(posts)).join('');
        this.postsContainer.innerHTML = postsHTML;
        this.bindPostEvents();
    }
    createPostHTML(post) {
        const user = post.user || {};
        const createdAt = this.formatDate(post.created_at);
        let imageHTML = '';
        if (post.image_url) {
            imageHTML = `<img src="${post.image_url}" alt="Post image" class="post-image">`;
        } else if (post.image) {
            imageHTML = `<img src="http://127.0.0.1:8000/storage/${post.image}" alt="Post image" class="post-image">`;
        }
        let userPhotoUrl = 'images/member-1.jpg';
        if (user.photo_url) {
            userPhotoUrl = user.photo_url;
        } else if (user.photo) {
            userPhotoUrl = `http://127.0.0.1:8000/storage/${user.photo}`;
        }
        return `
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="post-card" data-post-id="${post.id}">
                    <div class="post-header">
                        <img src="${userPhotoUrl}" alt="${user.name || 'User'}" class="post-user-avatar">
                        <div class="post-user-info">
                            <div class="post-user-name">${user.name || 'Anonymous User'}</div>
                            <div class="post-timestamp">
                                <i class="fa-solid fa-clock"></i>
                                ${createdAt}
                            </div>
                        </div>
                    </div>
                    <div class="post-content">
                        ${imageHTML}
                        <div class="post-text">${post.caption || post.content || 'No content'}</div>
                    </div>
                    <div class="post-actions">
                        <div class="post-action-left">
                            <button class="post-action-btn like-btn" data-post-id="${post.id}">
                                <i class="fa-solid fa-heart"></i>
                                <span>Like</span>
                            </button>
                            <button class="post-action-btn comment-btn" data-post-id="${post.id}">
                                <i class="fa-solid fa-comment"></i>
                                <span>Comment</span>
                            </button>
                            <button class="post-action-btn share-btn" data-post-id="${post.id}">
                                <i class="fa-solid fa-share"></i>
                                <span>Share</span>
                            </button>
                        </div>
                    </div>
                    <div class="post-comments" id="comments-${post.id}" style="display: none;"></div>
                </div>
            </div>
        `;
    }
    bindPostEvents() {
        // Event tombol like, comment, share pada setiap post
        document.querySelectorAll('.like-btn').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                e.preventDefault();
                const postId = btn.dataset.postId;
                await this.toggleLike(postId, btn);
            });
        });
        document.querySelectorAll('.comment-btn').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                e.preventDefault();
                const postId = btn.dataset.postId;
                await this.toggleComments(postId);
            });
        });
        document.querySelectorAll('.share-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                const postId = btn.dataset.postId;
                this.sharePost(postId);
            });
        });
    }
    sharePost(postId) {
        // Fungsi share post ke media sosial
        const post = this.posts.find(p => p.id == postId);
        if (!post) return;
        const shareData = {
            title: 'Check out this post!',
            text: post.content?.substring(0, 100) + '...',
            url: window.location.href + '#post-' + postId
        };
        if (navigator.share) {
            navigator.share(shareData);
        } else {
            const url = encodeURIComponent(window.location.href + '#post-' + postId);
            const text = encodeURIComponent(post.content?.substring(0, 100) + '...');
            window.open(`https://twitter.com/intent/tweet?text=${text}&url=${url}`, '_blank');
        }
    }
    formatDate(dateString) {
        // Format waktu post (misal: "2 jam yang lalu")
        if (!dateString) return 'Unknown time';
        const date = new Date(dateString);
        const now = new Date();
        const diffInSeconds = Math.floor((now - date) / 1000);
        if (diffInSeconds < 60) {
            return 'Baru saja';
        } else if (diffInSeconds < 3600) {
            const minutes = Math.floor(diffInSeconds / 60);
            return `${minutes} menit yang lalu`;
        } else if (diffInSeconds < 86400) {
            const hours = Math.floor(diffInSeconds / 3600);
            return `${hours} jam yang lalu`;
        } else if (diffInSeconds < 2592000) {
            const days = Math.floor(diffInSeconds / 86400);
            return `${days} hari yang lalu`;
        } else {
            return date.toLocaleDateString('id-ID', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            });
        }
    }
    showLoading() {
        // Tampilkan animasi loading saat post dimuat
        if (this.postsContainer) {
            this.postsContainer.innerHTML = `
                <div class="col-12 text-center">
                    <div class="loading-spinner">
                        <i class="fa-solid fa-spinner fa-spin fa-2x"></i>
                        <p class="mt-2">Memuat post...</p>
                    </div>
                </div>
            `;
        }
    }
    hideLoading() {}
    showNoPosts() {
        // Tampilkan pesan jika belum ada post
        if (this.postsContainer) {
            this.postsContainer.innerHTML = `
                <div class="col-12">
                    <div class="no-posts">
                        <i class="fa-solid fa-newspaper"></i>
                        <h3>Belum ada post</h3>
                        <p>Jadilah yang pertama untuk membuat post di aplikasi kami!</p>
                    </div>
                </div>
            `;
        }
    }
    showError(message) {
        // Tampilkan pesan error jika gagal load post
        if (this.postsContainer) {
            this.postsContainer.innerHTML = `
                <div class="col-12">
                    <div class="post-error">
                        <i class="fa-solid fa-exclamation-triangle"></i>
                        <h3>Oops! Terjadi kesalahan</h3>
                        <p>${message}</p>
                        <button class="btn-btn-1" onclick="postsManager.refreshPosts()">
                            <i class="fa-solid fa-refresh me-2"></i>Coba Lagi
                        </button>
                    </div>
                </div>
            `;
        }
    }
}

// Kelas untuk mengelola story (ambil, render, view, share, reply, refresh)
class StoriesManager {
    constructor() {
        console.log('StoriesManager constructor called');
        this.stories = [];
        this.loading = false;
        this.storiesContainer = document.getElementById('storiesRow');
        this.refreshBtn = document.getElementById('refreshStories');
        console.log('Stories container found:', !!this.storiesContainer);
        console.log('Refresh button found:', !!this.refreshBtn);
        this.init();
    }
    async init() {
        this.bindEvents();
        await this.loadStories();
    }
    bindEvents() {
        if (this.refreshBtn) {
            this.refreshBtn.addEventListener('click', () => this.refreshStories());
        }
    }
    async loadStories() {
        if (this.loading) return;
        this.loading = true;
        this.showLoading();
        try {
            const response = await api.getAllStories();
            console.log('Stories API Response:', response);
            let storiesData = [];
            if (response && Array.isArray(response)) {
                storiesData = response;
            } else if (response && response.data && Array.isArray(response.data)) {
                storiesData = response.data;
            } else if (response && response.data && Array.isArray(response.data.data)) {
                storiesData = response.data.data;
            }
            console.log('Stories data:', storiesData);
            if (storiesData.length > 0) {
                this.stories = storiesData;
                this.renderStories();
            } else {
                this.showNoStories();
            }
        } catch (error) {
            console.error('Error loading stories:', error);
            this.showError('Gagal memuat story dari server. Silakan coba lagi.');
        } finally {
            this.loading = false;
            this.hideLoading();
        }
    }
    async refreshStories() {
        await this.loadStories();
    }
    renderStories() {
        if (!this.storiesContainer) return;
        if (this.stories.length === 0) {
            this.showNoStories();
            return;
        }
        // Batasi jumlah story yang ditampilkan, misal 10
        const limit = 20;
        const limitedStories = this.stories.slice(0, limit);
        const storiesHTML = limitedStories.map(story => this.createStoryHTML(story)).join('');
        this.storiesContainer.innerHTML = storiesHTML;
        this.bindStoryEvents();
    }
    createStoryHTML(story) {
        const user = story.user || {};
        const createdAt = this.formatDate(story.created_at);
        let mediaHTML = '';
        if (story.video_url) {
            mediaHTML = `<video src="${story.video_url}" class="story-video" controls></video>`;
        } else if (story.image_url) {
            mediaHTML = `<img src="${story.image_url}" alt="Story image" class="story-image">`;
        }
        let userPhotoUrl = 'images/member-1.jpg';
        if (user.photo_url) {
            userPhotoUrl = user.photo_url;
        } else if (user.photo) {
            userPhotoUrl = `http://127.0.0.1:8000/storage/${user.photo}`;
        }
        return `
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="story-card" data-story-id="${story.id}">
                    <div class="story-header">
                        <img src="${userPhotoUrl}" alt="${user.name || 'User'}" class="story-user-avatar">
                        <div class="story-user-info">
                            <div class="story-user-name">${user.name || 'Anonymous User'}</div>
                            <div class="story-timestamp">
                                <i class="fa-solid fa-clock"></i>
                                ${createdAt}
                            </div>
                        </div>
                    </div>
                    <div class="story-content">
                        ${mediaHTML}
                        ${story.description ? `<div class="story-description">${story.description}</div>` : ''}
                    </div>
                    <div class="story-actions">
                        <div class="story-action-left">
                            <button class="story-action-btn view-btn" data-story-id="${story.id}">
                                <i class="fa-solid fa-eye"></i>
                                <span>View</span>
                            </button>
                            <button class="story-action-btn share-btn" data-story-id="${story.id}">
                                <i class="fa-solid fa-share"></i>
                                <span>Share</span>
                            </button>
                            <button class="story-action-btn reply-btn" data-story-id="${story.id}">
                                <i class="fa-solid fa-reply"></i>
                                <span>Reply</span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }
    bindStoryEvents() {
        // Event tombol view, share, reply pada setiap story
        document.querySelectorAll('.view-btn').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                e.preventDefault();
                const storyId = btn.dataset.storyId;
                await this.viewStory(storyId, btn);
            });
        });
        document.querySelectorAll('.share-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                const storyId = btn.dataset.storyId;
                this.shareStory(storyId);
            });
        });
        document.querySelectorAll('.reply-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                const storyId = btn.dataset.storyId;
                this.replyToStory(storyId);
            });
        });
    }
    shareStory(storyId) {
        // Fungsi share story ke media sosial
        const story = this.stories.find(s => s.id == storyId);
        if (!story) return;
        const shareData = {
            title: 'Check out this story!',
            text: story.description?.substring(0, 100) + '...',
            url: window.location.href + '#story-' + storyId
        };
        if (navigator.share) {
            navigator.share(shareData);
        } else {
            const url = encodeURIComponent(window.location.href + '#story-' + storyId);
            const text = encodeURIComponent(story.description?.substring(0, 100) + '...');
            window.open(`https://twitter.com/intent/tweet?text=${text}&url=${url}`, '_blank');
        }
    }
    formatDate(dateString) {
        // Format waktu story (misal: "2 jam yang lalu")
        if (!dateString) return 'Unknown time';
        const date = new Date(dateString);
        const now = new Date();
        const diffInSeconds = Math.floor((now - date) / 1000);
        if (diffInSeconds < 60) {
            return 'Baru saja';
        } else if (diffInSeconds < 3600) {
            const minutes = Math.floor(diffInSeconds / 60);
            return `${minutes} menit yang lalu`;
        } else if (diffInSeconds < 86400) {
            const hours = Math.floor(diffInSeconds / 3600);
            return `${hours} jam yang lalu`;
        } else if (diffInSeconds < 2592000) {
            const days = Math.floor(diffInSeconds / 86400);
            return `${days} hari yang lalu`;
        } else {
            return date.toLocaleDateString('id-ID', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            });
        }
    }
    showLoading() {
        // Tampilkan animasi loading saat story dimuat
        if (this.storiesContainer) {
            this.storiesContainer.innerHTML = `
                <div class="col-12 text-center">
                    <div class="loading-spinner">
                        <i class="fa-solid fa-spinner fa-spin fa-2x"></i>
                        <p class="mt-2">Memuat story...</p>
                    </div>
                </div>
            `;
        }
    }
    hideLoading() {}
    showNoStories() {
        // Tampilkan pesan jika belum ada story
        if (this.storiesContainer) {
            this.storiesContainer.innerHTML = `
                <div class="col-12">
                    <div class="no-stories">
                        <i class="fa-solid fa-book-open"></i>
                        <h3>Belum ada story</h3>
                        <p>Jadilah yang pertama untuk membuat story di aplikasi kami!</p>
                    </div>
                </div>
            `;
        }
    }
    showError(message) {
        // Tampilkan pesan error jika gagal load story
        if (this.storiesContainer) {
            this.storiesContainer.innerHTML = `
                <div class="col-12">
                    <div class="story-error">
                        <i class="fa-solid fa-exclamation-triangle"></i>
                        <h3>Oops! Terjadi kesalahan</h3>
                        <p>${message}</p>
                        <button class="btn-btn-1" onclick="storiesManager.refreshStories()">
                            <i class="fa-solid fa-refresh me-2"></i>Coba Lagi
                        </button>
                    </div>
                </div>
            `;
        }
    }
}

// Inisialisasi PostsManager dan StoriesManager saat DOM siap dan API tersedia
let postsManager;
let storiesManager;
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM Content Loaded');
    console.log('API service available:', !!window.api);
    setTimeout(() => {
        if (window.api) {
            console.log('Initializing PostsManager...');
            postsManager = new PostsManager();
            console.log('Initializing StoriesManager...');
            storiesManager = new StoriesManager();
        } else {
            console.error('API service not available');
        }
    }, 1000);
});

// Integrasi form kontak: kirim feedback ke API dan tampilkan notifikasi
// Sukses: alert sukses, Gagal: alert error
document.getElementById('contactForm')?.addEventListener('submit', async function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    const data = {
        subject: formData.get('subject'),
        message: formData.get('message')
    };
    try {
        const response = await api.submitFeedback(data);
        alert('Terima kasih! Pesan Anda telah terkirim. Kami akan menghubungi Anda segera.');
        this.reset();
    } catch (error) {
        console.error('Error submitting feedback:', error);
        alert('Gagal mengirim pesan. Silakan coba lagi.');
    }
});
