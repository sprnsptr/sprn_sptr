// Konfigurasi API dan pengaturan aplikasi
const CONFIG = {
    // URL API Backend - Sesuaikan dengan URL backend Laravel Anda
    API_BASE_URL: 'http://127.0.0.1:8000/api',
    
    // URL untuk development
    DEV_API_URL: 'http://127.0.0.1:8000/api',
    
    // URL untuk production (ganti dengan URL production Anda)
    PROD_API_URL: 'https://your-production-domain.com/api',
    
    // Pengaturan aplikasi
    APP_NAME: 'Social Media App',
    APP_VERSION: '1.0.0',
    
    // Pengaturan pagination
    POSTS_PER_PAGE: 10,
    
    // Timeout untuk request API (dalam milidetik)
    API_TIMEOUT: 10000,
    
    // Pengaturan cache
    CACHE_DURATION: 5 * 60 * 1000, // 5 menit dalam milidetik
    
    // Pengaturan UI
    ANIMATION_DURATION: 300,
    LOADING_DELAY: 1000,
    
    // Pengaturan error handling
    MAX_RETRY_ATTEMPTS: 3,
    RETRY_DELAY: 1000,
    
    // Pengaturan upload
    MAX_FILE_SIZE: 5 * 1024 * 1024, // 5MB
    ALLOWED_FILE_TYPES: ['image/jpeg', 'image/png', 'image/gif', 'image/webp'],
    
    // Pengaturan notifikasi
    NOTIFICATION_DURATION: 5000,
    
    // Pengaturan tema
    THEME: {
        PRIMARY_COLOR: '#723ee9',
        SECONDARY_COLOR: '#7d2fda',
        SUCCESS_COLOR: '#28a745',
        WARNING_COLOR: '#ffc107',
        ERROR_COLOR: '#dc3545',
        INFO_COLOR: '#17a2b8'
    }
};

// Fungsi untuk mendapatkan URL API berdasarkan environment
function getApiUrl() {
    // Deteksi environment berdasarkan URL
    const currentUrl = window.location.href;
    
    if (currentUrl.includes('localhost') || currentUrl.includes('127.0.0.1')) {
        return CONFIG.DEV_API_URL;
    } else {
        return CONFIG.PROD_API_URL;
    }
}

// Fungsi untuk mendapatkan konfigurasi berdasarkan environment
function getConfig() {
    return {
        ...CONFIG,
        API_BASE_URL: getApiUrl()
    };
}

// Export untuk penggunaan global
window.CONFIG = CONFIG;
window.getApiUrl = getApiUrl;
window.getConfig = getConfig; 